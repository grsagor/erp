<?php $__env->startSection('title', 'Dashboard | '.Helper::getSettings('application_name') ?? 'ERP'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-5 pt-4">
        <h4 class="mt-2">Dashboard</h4>
        
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\erp\resources\views/backend/pages/dashboard.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Attendance | ' . Helper::getSettings('application_name') ?? 'ERP'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h4 class="mt-2">Attendance Management</h4>
        <div class="mb-3 row">
            <label for="date" class="form-label m-0 d-flex align-items-center col-12 col-md-2">Select Date</label>
            <div class="col-12 col-md-10">
                <input type="text" class="form-control datepicker" id="date" placeholder="Select Date">
            </div>
        </div>

        <div id="attendance_container"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.datepicker').datepicker({
                format: 'dd/mm/yyyy',
                todayHighlight: true,
                autoclose: true
            }).datepicker('setDate', new Date());
            getFormHtml($('#date').val());

            $('#date').on('change', function() {
                getFormHtml($(this).val());
            })
        })

        function getFormHtml(date) {
            console.log(date)
            $.ajax({
                url: "<?php echo e(route('admin.attendance.single.day')); ?>",
                type: "get",
                data: {
                    date: date
                },
                dataType: "json",
                success: function(response) {
                    $('#attendance_container').html('');
                    $('#attendance_container').html(response.html);
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\erp\resources\views/backend/pages/attendance/index.blade.php ENDPATH**/ ?>
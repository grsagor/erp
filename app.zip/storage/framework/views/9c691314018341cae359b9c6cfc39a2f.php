<?php $__env->startSection('content'); ?>
    <div class="border-0 rounded-lg">
        <h3 class="text-center my-4">Login</h3>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(Session::has('message')): ?>
            <div class="alert alert-success alert-dismissible">
                <p class="m-0"><?php echo e(Session::get('message')); ?></p>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('login')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-floating mb-3">
                <input class="form-control" id="inputEmail" type="email" name="email" placeholder="name@example.com"
                    required />
                <label for="inputEmail">Email<span class="text-danger">*</span></label>
            </div>
            <div class="form-floating mb-3">
                <input class="form-control" id="inputPassword" name="password" type="password"
                    placeholder="<?php echo e(trans('language.label_password')); ?>" required />
                <label for="inputPassword">Password<span class="text-danger">*</span></label>
            </div>
            <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                <button type="submit" class="btn btn-primary w-100">Login</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.include.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\erp\resources\views/auth/login.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Role | '.Helper::getSettings('application_name') ?? 'ERP'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h4 class="mt-2">Role Edit</h4>
        
        <div class="card my-2">
            <div class="card-body">
                <form action="<?php echo e(route('admin.role.update', $role->id)); ?>" method="post" id="permission_form">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-12 form-group">
                            <label for="">Role Name</label>
                            <input type="text" class="form-control" name="" value="<?php echo e($role->name); ?>" readonly>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12 form-group">
                            <table class="col-lg-12 table table-bordered mt-4">
                                <thead>
                                    <tr>
                                        <th>Module Name</th>
                                        <th>Rights</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><span class="pl-2"><b class="text-capitalize">Select All:</b></span></td>
                                        <td><label for=""><input type="checkbox" id="selectall"> Select all</label></td>
                                    </tr>
                                    <?php $__currentLoopData = $rights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $right): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><span class="pl-2"><b class="text-capitalize"><?php echo e($right->module); ?>:</b></span></td> 
                                            <td>
                                                <?php $__currentLoopData = $right->rights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <label for="" class="role-label">
                                                        <input type="checkbox" class="permission-check" name="permission[<?php echo e($row->module); ?>][<?php echo e($row->id); ?>]" <?php if(Helper::hasRight($row->name, $role->id)): ?> checked <?php endif; ?> value="1">
                                                        <?php echo e(explode('.', $row->name)[1]); ?> 
                                                    </label>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-lg-12 form-group text-end">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php $__env->startPush('footer'); ?>
        <script type="text/javascript">
            $('#selectall').change(function(){
                $('#permission_form input:checkbox').not(this).prop('checked', this.checked);
                if($(this).is(':checked')){
                    $('#permission_form input:checkbox').not(this).val(1);
                }else{
                    $('#permission_form input:checkbox').not(this).val(0);
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\erp\resources\views/backend/pages/role/edit.blade.php ENDPATH**/ ?>
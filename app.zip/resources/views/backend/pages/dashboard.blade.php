@extends('backend.layout.app')
@section('title', 'Dashboard | '.Helper::getSettings('application_name') ?? 'ERP')
@section('content')
    <div class="container-fluid px-5 pt-4">
        <h4 class="mt-2">Dashboard</h4>
        
    </div>
@endsection



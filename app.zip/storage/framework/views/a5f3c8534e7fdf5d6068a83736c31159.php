<script>
    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }
</script>

<?php if(session()->has('success')): ?>
    <script>
        toastr.success('<?php echo e(session('success')); ?>');
    </script>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <script>
        toastr.error('<?php echo e(session('error')); ?>');
    </script>
<?php endif; ?><?php /**PATH E:\projects\erp\resources\views/shared/toastr.blade.php ENDPATH**/ ?>
<form id="editForm" method="post">
    <?php echo csrf_field(); ?> 
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
            <span aria-hidden="true"><i class="fa-solid fa-xmark"></i></span>
        </button>
    </div>
    <div class="modal-body">
        <div class="col-sm-12">
            <div class="server_side_error" role="alert">

            </div>
        </div>
        <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
        <div class="form-group  row">
            <label for="" class="col-sm-3 col-form-label">Select Customer</label>
            <div class="col-sm-9">
                <select name="customer_id" class="form-control" required>
                    <option value="">Select</option>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($order->customer_id == $customer->id ? 'selected' : ''); ?> value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-group  row">
            <label for="" class="col-sm-3 col-form-label">Quantity</label>
            <div class="col-sm-9">
                <input type="text" name="quantity" class="form-control" value="<?php echo e($order->quantity); ?>" placeholder="Quantity" required>
            </div>
        </div>
        <div class="form-group  row">
            <label for="" class="col-sm-3 col-form-label">Delivery Date</label>
            <div class="col-sm-9">
                <input type="text" name="delivery_date" class="form-control datepicker" value="<?php echo e($order->delivery_date); ?>" placeholder="Delivery Date" required>
            </div>
        </div>
        <div class="form-group  row">
            <label for="" class="col-sm-3 col-form-label">Status</label>
            <div class="col-sm-9">
                <select name="status" class="form-control" required>
                    <option value="">Select</option>
                    <option <?php echo e($order->status == 1 ? 'selected' : ''); ?> value="1">Pending</option>
                    <option <?php echo e($order->status == 2 ? 'selected' : ''); ?> value="2">In Progress</option>
                    <option <?php echo e($order->status == 3 ? 'selected' : ''); ?> value="3">Completed</option>
                </select>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <a type="button" class="modal__btn_space" data-bs-dismiss="modal">Close</a>
        <button type="submit" id="submitEditForm" class="btn btn-primary" data-check-area="modal-body">Update</button>
    </div>
</form><?php /**PATH E:\projects\erp\resources\views/backend/pages/order/edit.blade.php ENDPATH**/ ?>
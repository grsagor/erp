<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>
        <?php if (! empty(trim($__env->yieldContent('title')))): ?>
            <?php echo $__env->yieldContent('title'); ?>
        <?php else: ?>
            Dashboard | <?php echo e(Helper::getSettings('application_name')); ?>

        <?php endif; ?>
    </title>
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('vendor/fontawesome/css/all.min.css')); ?>">
    <link href="<?php echo e(asset('vendor/toastr/toastr.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('vendor/datatable/jquery.dataTables.min.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/summernote/summernote.min.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('vendor/datepicker/bootstrap-datepicker3.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/backend/css/style.css')); ?>" rel="stylesheet" />
    <link rel="shortcut icon" href="<?php echo e(asset(Helper::getSettings('site_favicon'))); ?>" />
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body class="sb-nav-fixed">
    <?php echo $__env->make('backend.include.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="layoutSidenav">
        <?php echo $__env->make('backend.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav_content">
            <main class="pt-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>

        </div>
    </div>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/jQuery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/toastr/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/sweetalert2/sweetalert2.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datepicker/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/validator/validator.js')); ?>"></script>


    <script>
        function previewFile(input, preview) {
            var file = $("#" + input + "").get(0).files[0];
            if (file) {
                var reader = new FileReader();
                reader.onload = function() {
                    $("#" + preview + "").attr("src", reader.result);
                }
                reader.readAsDataURL(file);
            }
        }

        function previewImage(input, previewContainerClass) {
            var preview = document.querySelector(previewContainerClass);
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        $('.select2').select2();
    </script>
    
    <?php echo $__env->make('shared.toastr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH E:\projects\erp\resources\views/backend/layout/app.blade.php ENDPATH**/ ?>
<form action="<?php echo e(route('admin.attendance.single.day.submit')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="date" value="<?php echo e($date); ?>">
    <table class="table table-hover">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Check In Time</th>
                <th scope="col">Check Out Time</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" name="employee_id[<?php echo e($i); ?>]" value="<?php echo e($employee->id); ?>">
                <tr>
                    <th scope="row"><?php echo e($i); ?></th>
                    <td><?php echo e($employee->name); ?></td>
                    <td><input type="time" name="check_in[<?php echo e($i); ?>]" class="form-control" value="<?php echo e(isset($employee->attendances[0]) ? $employee->attendances[0]->check_in : ''); ?>"></td>
                    <td><input type="time" name="check_out[<?php echo e($i); ?>]" class="form-control" value="<?php echo e(isset($employee->attendances[0]) ? $employee->attendances[0]->check_out : ''); ?>"></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="d-flex justify-content-end">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</form>
<?php /**PATH E:\projects\erp\resources\views/backend/pages/attendance/single-day-attendance.blade.php ENDPATH**/ ?>
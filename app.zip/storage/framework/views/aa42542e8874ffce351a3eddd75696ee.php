<div id="layoutSidenav_nav">

    <div class="user_profile">
        <img class="profile-image"
            src="<?php echo e(Auth::user()->profile_image ? asset(Auth::user()->profile_image) : asset('assets/utils/images/no-img.jpg')); ?>"
            alt="">

        <div class="profile-title"><?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?></div>
        <div class="profile-description"><?php echo e(Auth::user()->roles->name); ?></div>
    </div>

    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">

            <div class="nav">
                


                
                


                <?php if(Helper::hasRight('dashboard.view')): ?>
                    <a class="nav-link <?php echo e(Route::is('admin.index') ? 'active' : ''); ?>"
                        href="<?php echo e(route('admin.index')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div> Dashboard
                    </a>
                <?php endif; ?>

                <?php if(Helper::hasRight('hr.view')): ?>
                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#hrNav"
                        aria-expanded="<?php if(Route::is('admin.employee.index') ||
                                Route::is('admin.attendance.index')): ?> true <?php else: ?> false <?php endif; ?>"
                        aria-controls="collapseLayouts">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-gear"></i></div> HR Management
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse <?php if(Route::is('admin.employee.index') ||
                            Route::is('admin.attendance.index')): ?> show <?php endif; ?>" id="hrNav"
                        aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested nav down">
                            <?php if(Helper::hasRight('employee.view')): ?>
                                <a class="nav-link <?php echo e(Route::is('admin.employee.index') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('admin.employee.index')); ?>"><i
                                        class="fa-solid fa-angles-right ikon"></i> Employee Management </a>
                            <?php endif; ?>
                            <?php if(Helper::hasRight('attendance.view')): ?>
                                <a class="nav-link <?php echo e(Route::is('admin.attendance.index') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('admin.attendance.index')); ?>"><i
                                        class="fa-solid fa-angles-right ikon"></i> Attendance Management </a>
                            <?php endif; ?>
                        </nav>
                    </div>
                <?php endif; ?>
                <?php if(Helper::hasRight('hr.view')): ?>
                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#salesnorderNav"
                        aria-expanded="<?php if(Route::is('admin.customer.index') ||
                                Route::is('admin.customer.index')): ?> true <?php else: ?> false <?php endif; ?>"
                        aria-controls="collapseLayouts">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-gear"></i></div> Customer & Order
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse <?php if(Route::is('admin.customer.index') ||
                            Route::is('admin.order.index')): ?> show <?php endif; ?>" id="salesnorderNav"
                        aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested nav down">
                            <?php if(Helper::hasRight('customer.view')): ?>
                                <a class="nav-link <?php echo e(Route::is('admin.customer.index') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('admin.customer.index')); ?>"><i
                                        class="fa-solid fa-angles-right ikon"></i> Customer Management </a>
                            <?php endif; ?>
                            <?php if(Helper::hasRight('order.view')): ?>
                                <a class="nav-link <?php echo e(Route::is('admin.order.index') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('admin.order.index')); ?>"><i
                                        class="fa-solid fa-angles-right ikon"></i> Order Management </a>
                            <?php endif; ?>
                        </nav>
                    </div>
                <?php endif; ?>
                <?php if(Helper::hasRight('hr.view')): ?>
                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#rawMaterialsNav"
                        aria-expanded="<?php if(Route::is('admin.typeofrawmaterials.index') ||
                                Route::is('admin.typeofrawmaterials.index')): ?> true <?php else: ?> false <?php endif; ?>"
                        aria-controls="collapseLayouts">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-gear"></i></div> Raw Materials
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse <?php if(Route::is('admin.typeofrawmaterials.index') ||
                            Route::is('admin.order.index')): ?> show <?php endif; ?>" id="rawMaterialsNav"
                        aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested nav down">
                            <?php if(Helper::hasRight('typeofrawmaterials.view')): ?>
                                <a class="nav-link <?php echo e(Route::is('admin.typeofrawmaterials.index') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('admin.typeofrawmaterials.index')); ?>"><i
                                        class="fa-solid fa-angles-right ikon"></i> Material Type Management </a>
                            <?php endif; ?>
                        </nav>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </nav>
</div>
<?php /**PATH E:\projects\erp\resources\views/backend/include/sidebar.blade.php ENDPATH**/ ?>